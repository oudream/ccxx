/*---------------------------------------------------------------------
AccKernel.cpp - Samplest console application to serve as debuggee.  
Software Debugging by Raymond Zhang, All rights reserved. 
---------------------------------------------------------------------*/
#include "stdafx.h"

int main(int argc, char* argv[])
{
	printf("Hello, I am a tiny debuggee :-(\n");
	return getchar();
}

