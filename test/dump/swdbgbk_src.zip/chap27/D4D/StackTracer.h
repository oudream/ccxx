// StackTracer.h: interface for the CStackTracer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STACKTRACER_H__D0F25EEC_EA7F_48E4_9AED_C06815FFD980__INCLUDED_)
#define AFX_STACKTRACER_H__D0F25EEC_EA7F_48E4_9AED_C06815FFD980__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "D4dObject.h"

class CStackTracer : public CD4dObject  
{
public:
	CStackTracer();
	virtual ~CStackTracer();

};

#endif // !defined(AFX_STACKTRACER_H__D0F25EEC_EA7F_48E4_9AED_C06815FFD980__INCLUDED_)
