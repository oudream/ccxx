// D4dIntegerST.h: interface for the CD4dIntegerST class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_D4DINTEGERST_H__C16B5560_01FD_4CDC_9169_314FB458967A__INCLUDED_)
#define AFX_D4DINTEGERST_H__C16B5560_01FD_4CDC_9169_314FB458967A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "D4dInteger.h"

class D4D_API CD4dIntegerST : public CD4dInteger  
{
public:
	CD4dIntegerST();
	virtual ~CD4dIntegerST();

};

#endif // !defined(AFX_D4DINTEGERST_H__C16B5560_01FD_4CDC_9169_314FB458967A__INCLUDED_)
