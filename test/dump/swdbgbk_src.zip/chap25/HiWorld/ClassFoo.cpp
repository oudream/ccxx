#include "StdAfx.h"
#include "ClassFoo.h"

CClassFoo::CClassFoo(void)
{
}

CClassFoo::~CClassFoo(void)
{
}
int CClassFoo::Run(LPARAM lParam)
{
	return TRUE;
}