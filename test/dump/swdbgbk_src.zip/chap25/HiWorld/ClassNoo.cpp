#include "StdAfx.h"
#include "ClassNoo.h"

CClassNoo::CClassNoo(void)
{
}

CClassNoo::~CClassNoo(void)
{
}
