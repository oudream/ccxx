#pragma once
#include "baseclass.h"

class CClassNoo :
	virtual public CBaseClass
{
public:
	CClassNoo(void);
public:
	virtual ~CClassNoo(void);
};
