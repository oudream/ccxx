// Assert.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <crtdbg.h>
int main(int argc, char* argv[])
{
	_ASSERTE(argc>1);

	printf("Hello World!\n");
	return 0;
}

