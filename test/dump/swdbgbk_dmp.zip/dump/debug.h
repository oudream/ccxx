#if defined(DBG) && DBG
//#define DBGOUT(params) DbgPrint(params)
# define DBGOUT(params)				\
	{					\
		DbgPrint ("[REALBUG0.2] ");	\
		DbgPrint params;		\
		DbgPrint ("\n");		\
	}
# define TRAP(msg)				\
	{					\
		DBGOUT(("TRAP at file %s, line %d: '%s'.", __FILE__, __LINE__, msg)); \
		DbgBreakPoint();		\
        }
#else
# define DBGOUT(params)
# define TRAP(msg)
#endif