//----------------------------------------------------------------------
//
// RealBug - simple driver to serve as debuggee for training purpose.
// 
// Copyright (C) 2006 Raymond Zhang
// Advanced Debugging - http://advdbg.org
//
//----------------------------------------------------------------------
#include "ntddk.h"
#include "..\Imbuggy\ioctlcmd.h"
#include "debug.h"

#define MAX_LOOP 1
VOID SehFilter()
{
	int i;
	LARGE_INTEGER li;
	li.QuadPart=-100000;
	for(i=0;i<MAX_LOOP;i++)
	{
		DBGOUT(("Execute SEH filter now %d",KeGetCurrentIrql()));
		KeDelayExecutionThread(KernelMode,TRUE, &li); 
	}
}
VOID SehHandler()
{
	DBGOUT(("Execute handler now"));
}
VOID SEH()
{
	__try
	{
		__try
		{
			*(int *)0=1;
		}
		__except(SehFilter(), EXCEPTION_CONTINUE_SEARCH)
		{
			DBGOUT(("Never should reach here"));
		}
	}
    __except(SehFilter(), EXCEPTION_EXECUTE_HANDLER)
	{
		SehHandler();
	}
}
VOID UncaughtException()
{
	*(int *)0=1;
}
VOID NullPointer()
{
	*(int *)0=1;
}
#pragma warning(disable : 4723)
VOID PropDivideZero()
{
	int n,m;
	n=1;
	m=0;
	__try
	{
		n=n/m;
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		DBGOUT(("Caught divide by zero safely."));
	}
}
#pragma warning(default : 4723)

VOID DivideZero()
{
	int n,m;
	PropDivideZero();

	n=1;
	m=0;
	n=n/m;
}

VOID
StackOverflow( 
    PCHAR psz 
    )
{
	int i=0;
    CHAR szVar[10]="aaaaa...";

	for(i=0; i< 1000;i++)
		psz[i]=szVar[i];

}

NTSTATUS  
RealBugDeviceControl( 
    IN PFILE_OBJECT FileObject, 
    IN BOOLEAN Wait,
    IN PVOID InputBuffer, 
    IN ULONG InputBufferLength, 
    OUT PVOID OutputBuffer, 
    IN ULONG OutputBufferLength, 
    IN ULONG IoControlCode, 
    OUT PIO_STATUS_BLOCK IoStatus, 
    IN PDEVICE_OBJECT DeviceObject 
    ) 
{
    IoStatus->Status = STATUS_SUCCESS;
	IoStatus->Information = 0;

	switch ( IoControlCode ) {
    case IOCTL_DIVIDEBYZERO:
        DivideZero();
        break;
    case IOCTL_NULLPOINTER:
        NullPointer();
        break;
    case IOCTL_SEH:
        SEH();
        break;
    case IOCTL_EXCEPTION: 
        UncaughtException();
        break;
	case IOCTL_BUGCHECK:
		KeBugCheck(0x88888888);
		break;
	case IOCTL_STACK_OVERFLOW:
		StackOverflow("zzzzzz...");
		break;
    default: 
        IoStatus->Status = STATUS_NOT_SUPPORTED;
        break;
	}
	return IoStatus->Status;
}


NTSTATUS 
RealBugDispatch( 
    IN PDEVICE_OBJECT DeviceObject, 
    IN PIRP Irp 
    )
{
	PIO_STACK_LOCATION      iosp;
	PVOID                   inputBuffer;
	PVOID                   outputBuffer;
	ULONG                   inputBufferLength;
	ULONG                   outputBufferLength;
	ULONG                   ioControlCode;
	NTSTATUS                status;

    //
    // Switch on the request type
    //
	iosp = IoGetCurrentIrpStackLocation (Irp);
	switch (iosp->MajorFunction) {

    case IRP_MJ_CREATE:
    case IRP_MJ_CLOSE:

        status = STATUS_SUCCESS;
        break;

	case IRP_MJ_DEVICE_CONTROL:

        inputBuffer        = Irp->AssociatedIrp.SystemBuffer;
        inputBufferLength  = iosp->Parameters.DeviceIoControl.InputBufferLength;
        outputBuffer       = Irp->AssociatedIrp.SystemBuffer;
        outputBufferLength = iosp->Parameters.DeviceIoControl.OutputBufferLength;
        ioControlCode      = iosp->Parameters.DeviceIoControl.IoControlCode;
		status = RealBugDeviceControl( iosp->FileObject, TRUE,
                                       inputBuffer, inputBufferLength, 
                                       outputBuffer, outputBufferLength,
                                       ioControlCode, &Irp->IoStatus, 
                                       DeviceObject );
		break;

    default:

        status = STATUS_INVALID_DEVICE_REQUEST;
        break;        
	}

    //
    // Complete the request
    //
    Irp->IoStatus.Status = status;
	IoCompleteRequest( Irp, IO_NO_INCREMENT );
	return status;
}


VOID 
RealBugUnload( 
    IN PDRIVER_OBJECT DriverObject 
    )
{
	WCHAR                   deviceLinkBuffer[]  = L"\\Device\\RealBug";
	UNICODE_STRING          deviceLinkUnicodeString;

    //
	// Delete the symbolic link for our device
    //
	RtlInitUnicodeString( &deviceLinkUnicodeString, deviceLinkBuffer );
	IoDeleteSymbolicLink( &deviceLinkUnicodeString );

    //
	// Delete the device object
    //
	IoDeleteDevice( DriverObject->DeviceObject );
}


NTSTATUS 
DriverEntry(
    IN PDRIVER_OBJECT DriverObject, 
    IN PUNICODE_STRING RegistryPath 
    )
{
    NTSTATUS                status;
    WCHAR                   deviceNameBuffer[]  = L"\\Device\\RealBug";
    UNICODE_STRING          deviceNameUnicodeString;
    WCHAR                   deviceLinkBuffer[]  = L"\\DosDevices\\RealBug";
    UNICODE_STRING          deviceLinkUnicodeString;  
    PDEVICE_OBJECT          interfaceDevice = NULL;


    //
    // Create a named device object
    //
    RtlInitUnicodeString (&deviceNameUnicodeString,
                          deviceNameBuffer );
    status = IoCreateDevice ( DriverObject,
                                0,
                                &deviceNameUnicodeString,
                                FILE_DEVICE_RealBug,
                                0,
                                TRUE,
                                &interfaceDevice );
    if (NT_SUCCESS(status)) {

	   //
	   // Create a symbolic link that the GUI can specify to gain access
	   // to this driver/device
	   //
	   RtlInitUnicodeString (&deviceLinkUnicodeString,
							 deviceLinkBuffer );
	   status = IoCreateSymbolicLink (&deviceLinkUnicodeString,
										&deviceNameUnicodeString );

	   //
	   // Create dispatch points for all routines that must be RealBugd
	   //
	   DriverObject->MajorFunction[IRP_MJ_CREATE]          =
       DriverObject->MajorFunction[IRP_MJ_CLOSE]           =
       DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = RealBugDispatch;
	   DriverObject->DriverUnload                          = RealBugUnload;
    }
	
    if (!NT_SUCCESS(status)) {
      
	   //
	   // Something went wrong, so clean up 
	   //
	   if( interfaceDevice ) {

           IoDeleteDevice( interfaceDevice );
       }
    }

    return status;
}
    


