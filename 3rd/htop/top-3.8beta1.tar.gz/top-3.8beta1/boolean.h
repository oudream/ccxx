/* My favorite names for boolean values */
#define  No	0
#define  Yes	1
#define  Maybe	2		/* tri-state boolean, actually */

